/*

Template: COINEX - Crypto Currency HTML Template 
Author: iqonicthemes.in
Version: 2.0

*/

/*----------------------------------------------
Index Of Script
------------------------------------------------

1.Page Loader
2.Back To Top
3.Charts
4.Header
5.Jarallax
6.Searchstyle Bar
7.Progress Bar
8.Magnific Popup
9.Countdown
10.widget
11.counter
12.Wow Animation
13.Owl Carousel
14.Contact from

------------------------------------------------
Index Of Script
----------------------------------------------*/

$(document).ready(function() {

    /*------------------------
    Page Loader
    --------------------------*/
    jQuery("#load").fadeOut();
    jQuery("#loading").delay(0).fadeOut("slow");



    /*------------------------
    Back To Top
    --------------------------*/
    $('#back-to-top').fadeOut();
    $(window).on("scroll", function() {
        if ($(this).scrollTop() > 250) {
            $('#back-to-top').fadeIn(1400);
        } else {
            $('#back-to-top').fadeOut(400);
        }
    });
    // scroll body to 0px on click
    $('#top').on('click', function() {
        $('top').tooltip('hide');
        $('body,html').animate({
            scrollTop: 0
        }, 800);
        return false;
    });

    $('#down').on('click', function() {
        $('down').tooltip('hide');
        $('body,html').animate({
            scrollTop: $(document).height()-$(window).height()
        }, 800);
        return false;
    });

    /*------------------------
    Charts
    --------------------------*/
    (function(b, i, t, C, O, I, N) {
        window.addEventListener('load', function() {
            if (b.getElementById(C)) return;
            I = b.createElement(i), N = b.getElementsByTagName(i)[0];
            I.src = t;
            I.id = C;
            N.parentNode.insertBefore(I, N);
        }, false)

    });



    /*------------------------
    Header
    --------------------------*/
    $(window).on('scroll', function() {
        if ($(this).scrollTop() > 20) {
            $('header').addClass('menu-sticky');
        } else {
            $('header').removeClass('menu-sticky');
        }
    });
    var touch = $('#resp-menu');
    var menu = $('.menu');

    $(touch).on('click', function(e) {
        e.preventDefault();
        menu.slideToggle();
    });

    $(window).resize(function() {
        var w = $(window).width();
        if (w > 767 && menu.is(':hidden')) {
            menu.removeAttr('style');
        }
    });


    /*------------------------
    Jarallax
    --------------------------*/
    $('.jarallax').jarallax({
        speed: 0.2
    });



    /*------------------------
    Searchstyle Bar
    --------------------------*/
    $(".iq-search").on('click', function() {
        var checkId = document.getElementsByClassName("search-open");
        if (checkId.length > 0) {
            $('.iq-search').removeClass("search-open");
        } else {
            $('.iq-search').addClass("search-open");
        }
    })



    /*------------------------
    Progress Bar
    --------------------------*/
    $('.iq-progress-bar > span').each(function() {
        var $this = $(this);
        var width = $(this).data('percent');
        $this.css({
            'transition': 'width 2s'
        });
        setTimeout(function() {
            $this.appear(function() {
                $this.css('width', width + '%');
            });
        }, 500);
    });



    /*------------------------
    Magnific Popup
    --------------------------*/
    $('.popup-gallery').magnificPopup({
        delegate: 'a.popup-img',
        tLoading: 'Loading image #%curr%...',
        type: 'image',
        mainClass: 'mfp-img-mobile',
        gallery: {
            navigateByImgClick: true,
            enabled: true,
            preload: [0, 1]
        },
        image: {
            tError: '<a href="%url%">The image #%curr%</a> could not be loaded.'
        }
    });

    $('.popup-youtube, .popup-vimeo, .popup-gmaps').magnificPopup({
        type: 'iframe',
        disableOn: 700,
        mainClass: 'mfp-fade',
        preloader: false,
        removalDelay: 160,
        fixedContentPos: false
    });


    /*------------------------
    Countdown
    --------------------------*/
    $('#countdown').countdown({
        date: '10/01/2019 23:59:59',
        day: 'Day',
        days: 'Days'
    });


    /*------------------------
    widget
    --------------------------*/
    $('.iq-widget-menu > ul > li > a').on('click', function() {
        var checkElement = $(this).next();
        $('.iq-widget-menu li').removeClass('active');
        $(this).closest('li').addClass('active');
        if ((checkElement.is('ul')) && (checkElement.is(':visible'))) {
            $(this).closest('li').removeClass('active');
            checkElement.slideUp('normal');
        }
        if ((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
            $('.iq-widget-menu ul ul:visible').slideUp('normal');
            checkElement.slideDown('normal');
        }
        if ($(this).closest('li').find('ul').children().length === 0) {
            return true;
        } else {
            return false;
        }
    });



    /*------------------------
    counter
    --------------------------*/
    $('.timer').countTo();


    /*------------------------
    Wow Animation
    --------------------------*/
    new WOW().init();


    /*------------------------
    Owl Carousel
    --------------------------*/
    // $('.owl-carousel').each(function() {
    //     var $carousel = $(this);
    //     $carousel.owlCarousel({
    //         items: $carousel.data("items"),
    //         loop: $carousel.data("loop"),
    //         margin: $carousel.data("margin"),
    //         nav: $carousel.data("nav"),
    //         dots: $carousel.data("dots"),
    //         autoplay: $carousel.data("autoplay"),
    //         autoplayTimeout: $carousel.data("autoplay-timeout"),
    //         navText: ['<i class="fa fa-angle-left fa-2x"></i>', '<i class="fa fa-angle-right fa-2x"></i>'],
    //         responsiveClass: true,
    //         responsive: {
    //             // breakpoint from 0 up
    //             0: {
    //                 items: $carousel.data("items-mobile-sm")
    //             },
    //             // breakpoint from 480 up
    //             480: {
    //                 items: $carousel.data("items-mobile")
    //             },
    //             // breakpoint from 786 up
    //             786: {
    //                 items: $carousel.data("items-tab")
    //             },
    //             // breakpoint from 1023 up
    //             1023: {
    //                 items: $carousel.data("items-laptop")
    //             },
    //             1199: {
    //                 items: $carousel.data("items")
    //             }
    //         }
    //     });
    // });
    /*------------------------
    Contact from
    --------------------------*/
    $('#contact').submit(function(e) {
        var flag = 0;
        e.preventDefault(); // Prevent Default Submission
        $('.require').each(function() {
            if ($.trim($(this).val()) == '') {
                $(this).css("border", "1px solid red");
                e.preventDefault(); // Prevent Default Submission
                flag = 1;
            } else {
                $(this).css("border", "1px solid grey");
                flag = 0;
            }
        });

        if (grecaptcha.getResponse() == "") {
            flag = 1;
            alert('Please verify Recaptch');

        } else {
            flag = 0;
        }

        if (flag == 0) {
            $.ajax({
                    url: 'contact-form.php',
                    type: 'POST',
                    data: $("#contact").serialize() // it will serialize the form data
                })
                .done(function(data) {
                    $("#result").html('Form was successfully submitted.');
                    $('#contact')[0].reset();
                })
                .fail(function() {
                    alert('Ajax Submit Failed ...');
                });
        }

    });

});